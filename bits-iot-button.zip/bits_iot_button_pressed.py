import requests 

def lambda_handler(event, context):
    request = requests.post(url = os.environ['SLACK_URL'], data = {'text':'andon'})
    return request.text